#include <iostream>
#include <fstream>
#include "function.h"
#include "sstream"
#include <random>
#include <string>
#include <chrono>
#include <thread>
#include <vector>


using namespace std;

const int MAX_SIZE = 150;


using namespace std;

void showLoadingBar(int totalIterations) {
    const int barWidth = 40;
    for (int i = 0; i < totalIterations + 1; ++i) {

        // Calculate the percentage completed
        float progress = static_cast<float>(i) / totalIterations;

        // Calculate the number of characters to represent the progress in the loading bar
        int barLength = static_cast<int>(progress * barWidth);


        // Display the loading bar
        cout << "[";
        for (int j = 0; j < barWidth; ++j) {

            if (j < barLength) {
                cout << "=";
            } else {
                cout << " ";
            }
        }
        cout << "] " << int(progress * 100.0) << "%\r";
        cout.flush();


        // use for sleep
        // work like speed of FPS
        this_thread::sleep_for(chrono::milliseconds(50));
    }

    cout << endl;
}

void setCountDown(int num) {

    for (int i = num; i >= 0; --i) {
        cout << "\t\t" << i << "\r";
        cout.flush();
        this_thread::sleep_for(std::chrono::milliseconds(400));

    }
}


int Data::findSizeOfFile(int num) {
    if (num == 1) {
        int size = 0;
        string line;

        fstream input("Simple_Data.txt", ios::in);
        if (input.is_open()) {
            while (true) {

                getline(input, line);
                size++;
                if (input.eof()) {
                    break;
                }
            }
        }
        input.close();
        return size;
    } else if (num == 2) {
        int size = 0;
        string line;

        fstream input("Hard_Data.txt", ios::in);
        if (input.is_open()) {
            while (true) {

                getline(input, line);
                size++;
                if (input.eof()) {
                    break;
                }
            }
        }
        input.close();
        return size;
    } else {
        cout << "\nInvalid Input" << endl;
        return 1;
    }
}


int generateRandomNumber(int maxValue, int minValue = 0) {
    // Create a random device to seed the random number generator
    std::random_device rd;

    // Create a Mersenne Twister engine and seed it with the random device
    std::mt19937 gen(rd());

    // Create a uniform distribution for integers within the specified range
    std::uniform_int_distribution<> dist(minValue, maxValue);

    // Generate and return a random number
    return dist(gen);
}


void Data::generateLine(int num) {


    if (num == 1) {

        fstream input("Simple_Data.txt", ios::in);
        if (input.is_open()) {

            int size = findSizeOfFile(num);
            int random = generateRandomNumber(size);


            Data *data = new Data(size);
//Array array(size);

            for (int i = 0; i < size; i++) {

                getline(input, (*data).generated_line[i]);
            }

            (*data).current_Line = (*data).generated_line[random];

            setuser(data);

        }
        input.close();

    } else if (num == 2) {

        fstream input("Hard_Data.txt", ios::in);
        if (input.is_open()) {

            int size = findSizeOfFile(num);
            int random = generateRandomNumber(size);

            Data *data = new Data(size);

            for (int i = 0; i < size; i++) {

                getline(input, (*data).generated_line[i]);
            }

            (*data).current_Line = (*data).generated_line[random];

            setuser(data);


        }
        input.close();

    } else {
        cout << "\nInvalid Input" << endl;
    }
}


// Function to print colored text to the console
template<class T>
void printColoredText(T text, int colorCode) {

    // ANSI escape sequences for text color
    // 30-37: Foreground colors, 40-47: Background colors
    // 0: Reset, 1: Bold, 2: Dim, 3: Italic, 4: Underlined, 5: Blinking, 7: Reverse video, 8: Invisible

    cout << "\033[" << colorCode << "m" << text << "\033[0m";
}

Array Array::formArray(const string &inputLine) {
    Array arr;

    stringstream ss(inputLine);
    int wordCount = 0;

    // Tokenize the line into words
    while (ss >> arr.word[wordCount] && wordCount < MAX_SIZE) {
        wordCount++;
    }

/*
    // Display the separated words
    std::cout << "Separated words:" << std::endl;
    for (int k = 0; k < wordCount; ++k) {
        cout << arr.word[k] << endl;
    }
*/

    arr.count = wordCount;

    return arr;
}


bool Array::checkLine() {

    Data *data = getuser();
    int finalCount = 0;
    Array arr;
    Array arr1;
    arr = arr.formArray((*data).current_Line);
    arr1 = arr1.formArray((*data).matched_Line);

    for (int k = 0; k < arr.count; ++k) {
//        cout << arr.word[k] << "          " << arr1.word[k] << endl;


        int length = arr.word[k].size();
        int length1 = arr1.word[k].size();


        (*data).show_Word = new char[length];
        (*data).input_word = new char[length1];


        arr.word[k].copy((*data).show_Word, length);
        arr1.word[k].copy((*data).input_word, length1);


        int count = 0;


        cout << "     ";
        for (int i = 0; i < length; i++) {

            if ((*data).show_Word[i] == (*data).input_word[i]) {
                printColoredText((*data).input_word[i], 32);

                count++;
            } else {

                printColoredText((*data).input_word[i], 31);
                cout << "\a";

            }
        }

        if (count == length) {
            finalCount++;
        }
        delete[] (*data).show_Word;
        delete[] (*data).input_word;
    }

    cout << "\nSame Words :" << finalCount << endl;
    cout << "Total Words :" << arr.count << endl;

    if (finalCount == arr.count) {

        return true;
    } else {

        return false;
    }

}

void Array::mainFunction() {

    int num;
    cout << "\n1. Easy Line \n2. Difficult Lines" << endl;
    cout << "Enter Choice :";
    cin >> num;

    Data *data1;
    generateLine(num);
    data1 = getuser();

    if (data1 == nullptr) {
        cout << "farig kam" << endl;
        return;
    }
    cout << "\n\t\t\tLine You Entered" << endl;
    cout << "\n" << 1 << ". \t\t" << (*data1).current_Line;
    cout << endl;

    auto start = chrono::high_resolution_clock::now();
    // Your code here
    cout << "\nEnter Line :";
    cin.ignore();
    getline(cin, (*data1).matched_Line);

    auto end = chrono::high_resolution_clock::now();

    system("clear");
    cout << "\n\n\t\tChecking......." << endl;
    cout << "\n";
    int totalIterations = 50; // You can adjust the total number of iterations
    showLoadingBar(totalIterations);

    system("clear");
    cout << "\n\n\n\n\n\n";

    if (checkLine()) {
        cout << "\n\t\t\t***Matched***" << endl;
    } else {
        cout << "\n\t\t\t***Not Matched***" << endl;
    }

    chrono::duration<double> duration = end - start;
    cout << "Time elapsed: " << duration.count() << " seconds" << endl;


    delete[] (*data1).generated_line;
}





