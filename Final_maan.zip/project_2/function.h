#include <iostream>
#include <sstream>
#include <utility>

using namespace std;

class Data {
private :
    Data *data;
public:
    static int check_Data;
    string current_Line;
    string matched_Line;
    string *generated_line;
    char *show_Word{};
    char *input_word{};

    void setuser(Data *data1) {

        if (data1 != nullptr) {
            this->data = data1;
        }

    }

    Data(int size1 = 0) {
        data = nullptr;
        generated_line = new string[size1];
    }

    static int findSizeOfFile(int num);

    void generateLine(int num);

    Data *getuser() {
        return this->data;
    }


};

struct Array : public Data {

    string word[150];
    int count;

    static Array formArray(const string &inputLine);

    bool checkLine();

    void mainFunction();

};
void setCountDown(int num);
void showLoadingBar(int totalIterations);



