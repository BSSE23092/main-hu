

#include "function.h"

using namespace std;

int main() {
//    setCountDown(5);
    showLoadingBar(40);
//    Array arr;
//    arr.mainFunction();



    return 0;
}















//
//class Solution {
//public:
//    vector<vector<int>> generate(int num) {
//        vector<vector<int >> value;
//        vector<int> col;
//        if (num <= 0) {
//            cout << "\nInvalid Input" << endl;
//        }
//// find value by array
//
//        int values[5][5];
//        if (num <= 0) {
//            cout << "\nInvalid Input" << endl;
//        }
//
//        values[0][0] = 1;
//        values[1][0] = 1;
//        values[1][1] = 1;
//
//        if (num > 1) {
//            for (int i = 2; i < num; ++i) {
//                int k = 0;
//                values[i][0] = 1;
//
//                for (int j = 1; j < i + 2; ++j) {
//
//                    if (k == i ) {
//                        values[i][k] = 1;
//                    } else {
//                        values[i][j] = (values[i - 1][k] + values[i - 1][k + 1]);
//
//                    }
//                    k++;
//                }
//            }
//        }
//        if (num > 1) {
//            for (int i = 0; i < num; ++i) {
//                int size = i+1;
//               value.emplace_back(vector<int> (values[i] , values[i]+size));
//            }
//        }
//        return value;
//    }
//};
//
//void function(int num) {
//    int value[5][5];
//    int col[5];
//    if (num <= 0) {
//        cout << "\nInvalid Input" << endl;
//    }
//
//    col[0] = 1;
//    col[1] = 1;
//    value[0][0] = 1;
//    value[1][0] = col[0];
//    value[1][1] = col[1];
//    cout << "Values :" << value[1][0] << "  " << value[1][1] << endl;
//
//    if (num > 1) {
//        for (int i = 2; i < num; ++i) {
//            value[i][0] = 1;
//
//            int k = 0;
//            for (int j = 1; j < i + 2; ++j) {
//                if (k == i + 1) {
//                    value[i][j] = 1;
//                } else {
//                    value[i][j] = (value[i - 1][k] + value[i - 1][k + 1]);
//
//                }
//                k++;
//            }
//        }
//    }
//    for (int i = 0; i < num; ++i) {
//        for (int j = 0; j < i + 1; ++j) {
//
//            if (j == i) {
//                cout << value[i][j] << endl;
//            } else {
//                cout << value[i][j] << "  ,  ";
//
//            }
//        }
//
//    }
//}



// main part
//Solution a;
////    function(5);
//vector<vector<int >> value;
//value = a.generate(5);
//
//for (const auto &row: value) {
//for (int element: row) {
//cout << element << "    ";
//}
//cout << endl;
//}
//
